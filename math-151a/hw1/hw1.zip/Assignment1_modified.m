% Assignment1.m
%
% A sample matlab script (or m-file) that 
% plots a function 
%
%
x = 0:0.01:2.0*pi;
y = sin(x.^2);
plot(x,y);
